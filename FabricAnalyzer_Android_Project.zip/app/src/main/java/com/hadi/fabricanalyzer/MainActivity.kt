package com.hadi.fabricanalyzer

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

data class Cell(val color: Int, val relation: String)

class MainActivity : Activity() {
    private var rows = 20
    private var cols = 20
    private var colorCount = 4
    private var activeColor = 0
    private var mode = "رو"
    private var repeatRows = 4
    private var repeatCols = 4
    private var repeatVisible = false
    private val palette = mutableListOf(
        "#202020","#FFFFFF","#D62828","#F77F00","#FCBF49","#E9C46A","#2A9D8F","#0077B6",
        "#4361EE","#7209B7","#B5179E","#F4A6C1","#795548","#A5A58D","#6C757D","#70A1D7"
    )
    private val cells = mutableMapOf<Int, Cell>()
    private val systems = mutableMapOf<Int, String>()
    private lateinit var root: LinearLayout
    private lateinit var grid: FabricGrid
    private lateinit var status: TextView
    private lateinit var paletteBar: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; isAllCaps = false; textSize = 12f; setOnClickListener { action() } }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setBackgroundColor(Color.rgb(245,247,250))
        }
        val title = TextView(this).apply {
            text = "FABRIC ANALYZER  |  تجزیه بافت"
            textSize = 19f; setTextColor(Color.rgb(25,35,55)); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(title)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(button("ابعاد شبکه") { dimensionsDialog() })
        controls.addView(button("رنگ‌ها") { colorCountDialog() })
        controls.addView(button("سیستم پود") { systemDialog() })
        controls.addView(button("تکرار") { repeatDialog() })
        root.addView(controls)
        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        modes.addView(button("روی تار") { mode = "رو"; refreshStatus() })
        modes.addView(button("زیر تار") { mode = "زیر"; refreshStatus() })
        modes.addView(button("پاک‌کن") { mode = "پاک"; refreshStatus() })
        modes.addView(button("خروجی") { export() })
        root.addView(modes)
        paletteBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(paletteBar)
        status = TextView(this).apply { textSize = 12f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)
        grid = FabricGrid(this)
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bottom.addView(button("ذخیره") { save(); toast("پروژه روی گوشی ذخیره شد") })
        bottom.addView(button("پاک‌کردن همه") { confirmClear() })
        bottom.addView(button("نام‌گذاری پروژه") { nameDialog() })
        root.addView(bottom)
        setContentView(root)
        refreshPalette()
        refreshStatus()
    }

    private fun refreshPalette() {
        paletteBar.removeAllViews()
        for (i in 0 until colorCount) {
            val v = TextView(this).apply {
                text = if (i == activeColor) "✓" else "${i+1}"
                gravity = Gravity.CENTER
                textSize = 13f
                setTextColor(if (i == 1 || i == 4 || i == 5 || i == 11 || i == 13) Color.BLACK else Color.WHITE)
                setBackgroundColor(Color.parseColor(palette[i]))
                setPadding(dp(9), dp(7), dp(9), dp(7))
                setOnClickListener { activeColor = i; refreshPalette(); refreshStatus() }
                setOnLongClickListener { colorEditDialog(i); true }
            }
            val lp = LinearLayout.LayoutParams(0, dp(38), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            paletteBar.addView(v, lp)
        }
    }

    private fun refreshStatus() {
        status.text = "شبکه ${rows}×${cols}   |   ثبت: ${cells.size}   |   ابزار: $mode   |   رنگ ${activeColor+1} (${palette[activeColor]})"
        grid.invalidate()
    }

    private fun dimensionsDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40,10,40,0) }
        val r = EditText(this).apply { hint = "تعداد پود (۱۰ تا ۱۰۰)"; setText(rows.toString()); inputType = 2 }
        val c = EditText(this).apply { hint = "تعداد تار (۱۰ تا ۱۰۰)"; setText(cols.toString()); inputType = 2 }
        box.addView(r); box.addView(c)
        AlertDialog.Builder(this).setTitle("ابعاد شبکه").setView(box).setPositiveButton("اعمال") { _, _ ->
            val nr = (r.text.toString().toIntOrNull() ?: rows).coerceIn(10,100)
            val nc = (c.text.toString().toIntOrNull() ?: cols).coerceIn(10,100)
            val next = mutableMapOf<Int,Cell>()
            cells.forEach { (k,v) -> val oldR=k/cols; val oldC=k%cols; if(oldR<nr && oldC<nc) next[oldR*nc+oldC]=v }
            cells.clear(); cells.putAll(next); rows=nr; cols=nc
            repeatRows=min(repeatRows,rows); repeatCols=min(repeatCols,cols)
            refreshStatus(); save()
        }.setNegativeButton("لغو",null).show()
    }

    private fun colorCountDialog() {
        val input = EditText(this).apply { setText(colorCount.toString()); inputType=2; hint="۱ تا ۱۶" }
        AlertDialog.Builder(this).setTitle("تعداد رنگ").setMessage("تعداد رنگ‌های پالت (۱ تا ۱۶)").setView(input)
            .setPositiveButton("اعمال") { _, _ -> colorCount=(input.text.toString().toIntOrNull()?:colorCount).coerceIn(1,16); activeColor=min(activeColor,colorCount-1); refreshPalette(); refreshStatus(); save() }
            .setNegativeButton("لغو",null).show()
    }

    private fun colorEditDialog(i:Int) {
        val input=EditText(this).apply { setText(palette[i]); hint="#RRGGBB" }
        AlertDialog.Builder(this).setTitle("تغییر رنگ ${i+1}").setMessage("کد HEX را وارد کن").setView(input)
            .setPositiveButton("اعمال") { _,_ ->
                val value=input.text.toString().trim()
                try { Color.parseColor(value); palette[i]=value.uppercase(); refreshPalette(); refreshStatus(); save() }
                catch (_:Exception) { toast("کد رنگ معتبر نیست") }
            }.setNegativeButton("لغو",null).show()
    }

    private fun systemDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(40,0,40,0) }
        val n=EditText(this).apply { hint="شماره پود"; inputType=2 }
        val name=EditText(this).apply { hint="نام سیستم؛ مثلاً شانل زمینه" }
        box.addView(n); box.addView(name)
        AlertDialog.Builder(this).setTitle("نام‌گذاری سیستم پود").setView(box)
            .setPositiveButton("ثبت") { _,_ ->
                val row=(n.text.toString().toIntOrNull()?:1).coerceIn(1,rows)-1
                systems[row]=name.text.toString(); save(); toast("نام سیستم پود ${row+1} ثبت شد")
            }.setNegativeButton("لغو",null).show()
    }

    private fun repeatDialog() {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(40,0,40,0) }
        val r=EditText(this).apply { hint="تعداد پود"; setText(repeatRows.toString()); inputType=2 }
        val c=EditText(this).apply { hint="تعداد تار"; setText(repeatCols.toString()); inputType=2 }
        val check=CheckBox(this).apply { text="نمایش محدوده تکرار"; isChecked=repeatVisible }
        box.addView(r); box.addView(c); box.addView(check)
        AlertDialog.Builder(this).setTitle("محدوده تکرار").setView(box)
            .setPositiveButton("اعمال") { _,_ -> repeatRows=(r.text.toString().toIntOrNull()?:repeatRows).coerceIn(1,rows); repeatCols=(c.text.toString().toIntOrNull()?:repeatCols).coerceIn(1,cols); repeatVisible=check.isChecked; grid.invalidate(); save() }
            .setNegativeButton("لغو",null).show()
    }

    private fun nameDialog() {
        val input=EditText(this).apply { setText(projectName); hint="نام پروژه" }
        AlertDialog.Builder(this).setTitle("نام پروژه").setView(input)
            .setPositiveButton("ثبت") { _,_ -> projectName=input.text.toString().ifBlank{"طرح بدون نام"}; save(); toast("نام پروژه ذخیره شد") }
            .setNegativeButton("لغو",null).show()
    }
    private var projectName="طرح بدون نام"

    private fun confirmClear() {
        AlertDialog.Builder(this).setTitle("پاک‌کردن شبکه؟").setMessage("تمام خانه‌های ثبت‌شده پاک شوند؟")
            .setPositiveButton("پاک کن") { _,_ -> cells.clear(); refreshStatus(); save() }.setNegativeButton("لغو",null).show()
    }

    private fun export() {
        val text=buildString {
            append("FABRIC ANALYZER\n$projectName\nRows=$rows Columns=$cols\nR=روی تار U=زیر تار -=خالی\n")
            for(r in 0 until rows) {
                for(c in 0 until cols) {
                    val x=cells[r*cols+c]
                    append(if(x==null) "- " else "${if(x.relation=="رو")"R" else "U"}${x.color+1} ")
                }
                append("\n")
            }
            append("\nسیستم پود:\n")
            for(r in 0 until rows) append("پود ${r+1}: ${systems[r]?: "بدون نام"}\n")
        }
        val send=Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_SUBJECT,projectName); putExtra(Intent.EXTRA_TEXT,text) }
        startActivity(Intent.createChooser(send,"خروجی نقشه بافت"))
    }

    private fun save() {
        val obj=JSONObject()
        obj.put("rows",rows); obj.put("cols",cols); obj.put("colorCount",colorCount); obj.put("activeColor",activeColor)
        obj.put("palette",JSONArray(palette)); obj.put("repeatRows",repeatRows); obj.put("repeatCols",repeatCols); obj.put("repeatVisible",repeatVisible); obj.put("projectName",projectName)
        val arr=JSONArray()
        cells.forEach { (k,v) -> arr.put(JSONObject().put("key",k).put("color",v.color).put("relation",v.relation)) }
        obj.put("cells",arr)
        val sys=JSONObject(); systems.forEach { (k,v)->sys.put(k.toString(),v) }; obj.put("systems",sys)
        getSharedPreferences("fabric",Context.MODE_PRIVATE).edit().putString("project",obj.toString()).apply()
    }

    private fun load() {
        try {
            val raw=getSharedPreferences("fabric",Context.MODE_PRIVATE).getString("project",null) ?: return
            val o=JSONObject(raw)
            rows=o.optInt("rows",20).coerceIn(10,100); cols=o.optInt("cols",20).coerceIn(10,100)
            colorCount=o.optInt("colorCount",4).coerceIn(1,16); activeColor=o.optInt("activeColor",0).coerceIn(0,15)
            val p=o.optJSONArray("palette"); if(p!=null) for(i in 0 until min(16,p.length())) palette[i]=p.getString(i)
            repeatRows=o.optInt("repeatRows",4).coerceIn(1,rows); repeatCols=o.optInt("repeatCols",4).coerceIn(1,cols)
            repeatVisible=o.optBoolean("repeatVisible",false); projectName=o.optString("projectName","طرح بدون نام")
            val a=o.optJSONArray("cells"); if(a!=null) for(i in 0 until a.length()) { val x=a.getJSONObject(i); cells[x.getInt("key")]=Cell(x.getInt("color"),x.getString("relation")) }
            val s=o.optJSONObject("systems"); if(s!=null) s.keys().forEach { systems[it.toInt()]=s.getString(it) }
        } catch (_:Exception) { }
    }

    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    override fun onPause() { save(); super.onPause() }

    inner class FabricGrid(context:Context):View(context) {
        private val paint=Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas:Canvas) {
            super.onDraw(canvas)
            val cw=width.toFloat()/cols; val ch=height.toFloat()/rows
            for(r in 0 until rows) for(c in 0 until cols) {
                val x=cells[r*cols+c]
                paint.color=if(x==null) Color.WHITE else try { Color.parseColor(palette[x.color]) } catch(_:Exception){Color.GRAY}
                canvas.drawRect(c*cw,r*ch,(c+1)*cw,(r+1)*ch,paint)
                if(x!=null) {
                    paint.color=if(x.relation=="رو") Color.rgb(30,100,210) else Color.rgb(210,50,50)
                    paint.style=Paint.Style.STROKE; paint.strokeWidth=max(1f,resources.displayMetrics.density)
                    if(x.relation=="رو") canvas.drawCircle((c+.5f)*cw,(r+.5f)*ch,min(cw,ch)*.17f,paint)
                    else {
                        canvas.drawLine(c*cw+cw*.3f,r*ch+ch*.3f,(c+1)*cw-cw*.3f,(r+1)*ch-ch*.3f,paint)
                        canvas.drawLine((c+1)*cw-cw*.3f,r*ch+ch*.3f,c*cw+cw*.3f,(r+1)*ch-ch*.3f,paint)
                    }
                    paint.style=Paint.Style.FILL
                }
                paint.color=Color.LTGRAY; paint.style=Paint.Style.STROKE; paint.strokeWidth=.6f
                canvas.drawRect(c*cw,r*ch,(c+1)*cw,(r+1)*ch,paint)
                paint.style=Paint.Style.FILL
            }
            if(repeatVisible) {
                paint.color=Color.rgb(20,160,80); paint.style=Paint.Style.STROKE; paint.strokeWidth=dp(3).toFloat()
                canvas.drawRect(0f,0f,cw*repeatCols,ch*repeatRows,paint); paint.style=Paint.Style.FILL
            }
        }
        override fun onTouchEvent(event:MotionEvent):Boolean {
            if(event.action==MotionEvent.ACTION_DOWN) {
                val c=floor(event.x/(width.toFloat()/cols)).toInt().coerceIn(0,cols-1)
                val r=floor(event.y/(height.toFloat()/rows)).toInt().coerceIn(0,rows-1)
                val k=r*cols+c
                val old=cells[k]
                if(mode=="پاک") cells.remove(k)
                else if(old!=null && old.color==activeColor && old.relation==mode) cells.remove(k)
                else cells[k]=Cell(activeColor,mode)
                refreshStatus(); save(); return true
            }
            return true
        }
    }
}
